package com.perisic.beds;

/**
 * @author tm
 *
 */
public class Tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		CustomerPanel thePanel = new CustomerPanel(new Display()); 
		thePanel.itemReceived(1); 
		thePanel.itemReceived(2); 
		thePanel.itemReceived(1); 
		thePanel.itemReceived(3);
		thePanel.itemReceived(4);
		thePanel.printReceipt(); 
	}

}
