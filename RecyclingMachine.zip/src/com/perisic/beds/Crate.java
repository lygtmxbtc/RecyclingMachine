package com.perisic.beds;

/**
 * @author tm
 *
 */
public class Crate extends DepositItem {
	static int weight = 120; 
	static int size = 80; 
	/**
	 * 
	 */
	public Crate() { 
		value = 200; 
	}
}
