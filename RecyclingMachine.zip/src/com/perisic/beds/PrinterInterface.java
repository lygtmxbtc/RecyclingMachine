package com.perisic.beds;

public interface PrinterInterface {
	public void print(String str); 
}
