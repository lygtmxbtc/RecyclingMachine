package com.perisic.beds;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import javax.swing.*;

import com.perisic.beds.rmiinterface.RecyclingRMI;

/**
 * A Simple Graphical User Interface for the Recycling Machine.
 * @author tm
 *
 */
public class RecyclingGUIServer extends JFrame implements ActionListener  {
	public void actionPerformed(ActionEvent e) {
		//System.out.println("Thanks for pressing a button!");
		//System.out.println("Received: e.getActionCommand()="+e.getActionCommand()+
			//				" e.getSource()="+e.getSource().toString() );
		if(e.getSource().equals(slot1) ) { 
			myCustomerPanel.itemReceived(1);
		} else if(e.getSource().equals(slot2) ) { 
			myCustomerPanel.itemReceived(2);
		} else if(e.getSource().equals(slot3) ) { 
			myCustomerPanel.itemReceived(3);
		} else if(e.getSource().equals(receipt)) { 
			myCustomerPanel.printReceipt();
		}
		
	}
	
	JButton slot1 = new JButton("Slot 1"); 
	JButton slot2 = new JButton("Slot 2"); 
	JButton slot3 = new JButton("Slot 3"); 
	
	JButton receipt = new JButton("Receipt"); 
	
	CustomerPanel myCustomerPanel = new CustomerPanel(new Display()); 

	
	public RecyclingGUIServer() {
		super();
		setSize(400, 100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
		JPanel panel = new JPanel(); 
		panel.add(slot1); 
		panel.add(slot2);
		panel.add(slot3); 
		
		slot1.addActionListener(this); 
		slot2.addActionListener(this); 
		slot3.addActionListener(this); 
		
		panel.add(receipt); 
		receipt.addActionListener(this); 
		
		
		
		getContentPane().add(panel);
		panel.repaint();
	
	}
	
	public static void main(String [] args ) { 
		RecyclingGUIServer myGUI = new RecyclingGUIServer(); 
		myGUI.setVisible(true); 
		
		try {
			
			RecyclingRMIImplementation theImplementation 
								= new RecyclingRMIImplementation();
			theImplementation.setPanel(myGUI.myCustomerPanel);
			RecyclingRMI helloImpl = theImplementation;  
		
			Registry reg = LocateRegistry.createRegistry(1099);
			reg.rebind("RecyclingService",helloImpl);
			System.out.println("Starting Service. Welcome to RMI - Recycling!");
	     } catch (Exception e) {
	       System.out.println("Trouble: " + e);
	     }
		
	}

}