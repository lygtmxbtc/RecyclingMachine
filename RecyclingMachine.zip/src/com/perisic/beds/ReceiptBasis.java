package com.perisic.beds;
import java.util.Vector; 

/**
 * Represents the Database of the systems. It temporarily stores the items that went into the machine.
 * @author tm
 *
 */
public class ReceiptBasis {
	private Vector<DepositItem> myItems = new Vector<DepositItem>();
	/**
	 * Adds an item to the database. 
	 * @param item the item that is inserted (can, bottle or crate, e.g.).
	 */
	public void addItem(DepositItem item) { 
		myItems.add(item); 
		item.number = myItems.indexOf(item); 
	}
	/**
	 * Generates the receipt by adding the values of the items together. 
	 * @return a string representing the receipt. 
	 */
	public String computeSum() { 
		String receipt = ""; 
		int sum = 0; 
		for(int i=0; i < myItems.size(); i++ ) {
			DepositItem item = myItems.get(i); 
			receipt = receipt + item.number +": "+item.value; 
			receipt = receipt + System.getProperty("line.separator");
			sum = sum + item.value; 
		}
		receipt = receipt + "Total: "+sum; 
		return receipt; 
	}
}
