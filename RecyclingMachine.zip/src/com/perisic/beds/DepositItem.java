package com.perisic.beds;

/**
 * Represents a generic item that is stored in the Recycling Machine. 
 * @author tm
 *
 */
public abstract class DepositItem {
	int number; 
	int value; 
}
