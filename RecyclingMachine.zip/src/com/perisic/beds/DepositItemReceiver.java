package com.perisic.beds;


/**
 * The overall controller of the system. Represents the Recycling Machine.
 * @author tm
 *
 */
public class DepositItemReceiver {
	/**
	 * Initialise the System with the output device. 
	 * @param printer
	 */
	public DepositItemReceiver(PrinterInterface printer) {
		super();
		this.printer = printer;
	}
	
	private ReceiptBasis theReceiptBasis = null; 
	private PrinterInterface printer = null;  
	/**
	 * 
	 */
	public void createReceiptBasis() { 
		theReceiptBasis = new ReceiptBasis(); 
	}
	
	private int itemCounter = 0; 
	/**
	 * @param slot
	 */
	public void classifyItem(int slot) { 
		DepositItem item = null; 
		if( slot == 1 ) { 
			item = new Can(); 
		} else if( slot == 2 ) { 
			item = new Bottle(); 
		} else if ( slot == 3 ) { 
			item = new Crate(); 
		} else if (slot == 4 ) { 
			item = new PaperBag(); 
		}
		if( theReceiptBasis == null ) { 
			createReceiptBasis(); 
		}
		theReceiptBasis.addItem(item); 
		itemCounter = itemCounter + 1; 
	}
	/**
	 * 
	 */
	public void printReceipt() { 
		String str = theReceiptBasis.computeSum(); 
		printer.print(str); 
		theReceiptBasis = null; 
	}
	public int getNumberOfItems() {
		
		return itemCounter;
	}
}
