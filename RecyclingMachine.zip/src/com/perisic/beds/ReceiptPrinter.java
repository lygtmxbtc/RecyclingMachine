package com.perisic.beds;

/**
 * 
 * Output interface. At the moment prints to the console. 
 * 
 * @author tm
 *
 */
public class ReceiptPrinter implements PrinterInterface {
	/**
	 * Prints a string to the console window. 
	 * @param str the receipt to be printed. 
	 */
	public void print(String str) { 
		System.out.println(str);
	}
}
