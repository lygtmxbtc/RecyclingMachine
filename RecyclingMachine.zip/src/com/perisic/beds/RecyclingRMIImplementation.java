package com.perisic.beds;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import com.perisic.beds.rmiinterface.RecyclingRMI;

public class RecyclingRMIImplementation extends UnicastRemoteObject 
			implements RecyclingRMI {

	private static final long serialVersionUID = 1L;
	
	public RecyclingRMIImplementation() throws RemoteException {
		// TODO Auto-generated constructor stub
		super();
	}

	public RecyclingRMIImplementation(int arg0) throws RemoteException {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	private CustomerPanel myPanel; 
	
	void setPanel(CustomerPanel thePanel) { 
		myPanel = thePanel; 
	}
	//@Override
	//public String sayHello() {
	//	return "Hello World. How are you?";
	//}

	@Override
	public int getNumberOfItems() throws RemoteException {
		// TODO Auto-generated method stub
		// for the moment we assume there are 18 items in the machine. We will then 
		// later link this to the 'real' recycling machine. 
		return myPanel.getNumberOfItems(); 
	}

}
