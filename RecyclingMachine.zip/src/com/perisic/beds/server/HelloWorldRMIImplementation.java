package com.perisic.beds.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import com.perisic.beds.rmiinterface.HelloWorldRMI;

public class HelloWorldRMIImplementation extends UnicastRemoteObject implements HelloWorldRMI {

	private static final long serialVersionUID = 1L;
	
	public HelloWorldRMIImplementation() throws RemoteException {
		// TODO Auto-generated constructor stub
		super();
	}

	public HelloWorldRMIImplementation(int arg0) throws RemoteException {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public String sayHello() {
		return "Hello World. How are you?";
	}

}
