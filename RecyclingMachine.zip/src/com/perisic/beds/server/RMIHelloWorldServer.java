package com.perisic.beds.server;

import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import com.perisic.beds.rmiinterface.HelloWorldRMI;



public class RMIHelloWorldServer {
	/**
	 * Where everything starts. 
	 * @param args
	 */
	public static void main(String [] args ) { 
	
		try {
			HelloWorldRMI helloImpl = new HelloWorldRMIImplementation();
			Registry reg = LocateRegistry.createRegistry(1099);
			reg.rebind("HelloWorldService",helloImpl);
			System.out.println("Starting Service. Welcome to RMI!");
	     } catch (Exception e) {
	       System.out.println("Trouble: " + e);
	     }
		
	}
}
