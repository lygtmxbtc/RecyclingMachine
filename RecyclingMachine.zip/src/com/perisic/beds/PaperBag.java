package com.perisic.beds;

/**
 * Represents a bottle returned by the customer. 
 * @author tm
 *
 */
public class PaperBag extends DepositItem {
	static int weight = 10; 
	static int size = 8; 
	/**
	 * The bottle is initialised with a value of 15. 
	 */
	public PaperBag() { 
		value = 2; 
	}
}
