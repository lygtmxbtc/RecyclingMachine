package com.perisic.beds;

/**
 * @author tm
 *
 */
public class Can extends DepositItem {
	static int weight = 5; 
	static int size = 6; 
	public Can() { 
		value = 20; 
	}
}
