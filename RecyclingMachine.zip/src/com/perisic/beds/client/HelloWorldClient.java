package com.perisic.beds.client;

import java.rmi.Naming;
import com.perisic.beds.rmiinterface.*; 

/**
 * Example of a Hello World RMI client
 * @author tm
 *
 */
public class HelloWorldClient {


	public static void main (String [] args) {
		try {
			HelloWorldRMI rc 
			= (HelloWorldRMI) Naming.lookup("rmi://localhost/HelloWorldService"); 
			System.out.println(rc.sayHello());
		} catch (Exception exception) {
			System.err.println("JavaClient: " + exception);
		}
	}
}