package com.perisic.beds.client;

import java.rmi.Naming;
import com.perisic.beds.rmiinterface.*; 

/**
 * Example of a Hello World RMI client
 * @author tm
 *
 */
public class RecyclingClient {


	public static void main (String [] args) {
		try {
			RecyclingRMI rc 
			= (RecyclingRMI) Naming.lookup("rmi://localhost/RecyclingService"); 
			System.out.println(rc.getNumberOfItems());
		} catch (Exception exception) {
			System.err.println("JavaClient: " + exception);
		}
	}
}