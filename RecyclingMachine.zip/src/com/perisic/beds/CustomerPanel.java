package com.perisic.beds;

/**
 * Interfaces with the customer that comes to the machine and inserts items. 
 * @author tm
 *
 */
public class CustomerPanel {
	
	DepositItemReceiver receiver = null; 

	public CustomerPanel(PrinterInterface printer) {
		super();
		this.receiver = new DepositItemReceiver(printer);
	}
	
	public int getNumberOfItems() { 
		return receiver.getNumberOfItems(); 
	}
	/**
	 * An item has been inserted into the slot.
	 * @param slot the slot in which the item has been inserted. 
	 */
	public void itemReceived(int slot) { 
		receiver.classifyItem(slot); 
	}
	/**
	 * requests from the machine to print a receipt. 
	 */
	public void printReceipt() { 
		receiver.printReceipt();
	}
}
