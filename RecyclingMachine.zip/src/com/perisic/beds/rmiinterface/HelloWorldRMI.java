package com.perisic.beds.rmiinterface;


import java.rmi.Remote;
import java.rmi.RemoteException;
public interface HelloWorldRMI extends Remote {

	public String sayHello() throws RemoteException; 
}
