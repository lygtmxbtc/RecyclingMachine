package com.perisic.beds.rmiinterface;


import java.rmi.Remote;
import java.rmi.RemoteException;
public interface RecyclingRMI extends Remote {

	// public String sayHello() throws RemoteException;
	public int getNumberOfItems() throws RemoteException; 
}